# Changelog

## 1.0.0 (2026-04-02)

### Initial Release
- Unified Security Analysis (Titolo 360)
  - 6-component scoring engine (Technical, Macro, Sector, Smart Money, Fundamentals, Risk)
  - Convergence matrix (STRONG/PARTIAL/DIVERGENT/INSUFFICIENT)
  - Actionability classification (HIGH/MEDIUM/LOW/DISCOVERY_ONLY)
  - Form 4 insider weight 3.5x, 13F weight 0.5x
- AI Enrichment
  - Claude AI: fundamentals, bull/bear factors, trade plan
  - Perplexity: smart money research, institutional data, news
- Financial Planner
  - PAC (Piano di Accumulo Capitale)
  - Income projection with safe withdrawal rate
  - Retirement simulation (accumulation + decumulation)
  - AI-driven portfolio allocation
- Email Digest
  - HTML + plain-text multipart
  - Hourly scheduler with market hours detection
  - Hash-based deduplication
  - Change detection (rating, convergence shifts)
  - Gmail App Password support
- Yahoo Finance Chart API v8 integration
- Full HA Ingress support
- Mobile responsive dark theme UI
- PayPal donate integration
